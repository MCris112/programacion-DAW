public interface Identificacion {

    String identificate();
}
